var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var gameState = "play";
var thief = createSprite(10,390,30,30);

var laser1 = createSprite(100,0,200,5);
  laser1.shapeColor = "green";
  laser1.velocityY = 3;
var laser2 = createSprite(300,400,200,5);
  laser2.shapeColor = "green";
  laser2.velocityY = -3;
var diamondBox = createSprite(390,10,30,30);
  diamondBox.shapeColor="blue";




createEdgeSprites();

function draw() {
 background(220);
if (gameState == "play") {
  
  
  textSize(24);
  textFont("Calibri");
  stroke("blue");
  fill("blue");
  text("Atrapa el ladron", 120, 200);
  

 if (keyDown(RIGHT_ARROW)) {
    thief.x = thief.x +2;
  }
  if (keyDown(LEFT_ARROW)) {
    thief.x = thief.x -2;
  }
  if (keyDown(DOWN_ARROW)) {
    thief.y = thief.y +2;
  }
  if (keyDown(UP_ARROW)) {
    thief.y = thief.y -2;
  }
  
if (thief.isTouching(laser1) || 
    thief.isTouching(laser2)){
      laser1.velocityY = 0;
      laser2.velocityY = 0;
      gameState = "lose";
    
}
if (thief.isTouching(diamondBox)) {
        gameState = "win";
      }
            
    
}
    

 if (gameState === "win") {
  textSize(40);
  textFont("Calibri");
  stroke("green");
  fill("green");
  text("El ladron ha conseguido el diamante", 0, 200);
  }
  
  
  if (gameState === "lose") {
  textSize(40);
  textFont("Calibri");
  stroke("red");
  fill("red");
  text("ladron atrapado", 75, 200);
    }

  
  
  laser1.bounceOff(edges); 
  laser2.bounceOff(edges);
  thief.bounceOff(edges);
  
  drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
